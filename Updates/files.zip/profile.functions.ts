import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Must mirror the option lists in src/routes/_authenticated/onboarding.tsx.
// Keep these in sync if the UI options ever change.
const VALID_ROLES = ["Beginner / learning", "Career-switcher", "IT / engineer", "Business owner", "Executive / leadership", "Other"];
const VALID_INDUSTRIES = ["all", "healthcare", "finance", "retail", "tech", "education", "government", "other"];
const VALID_LEVELS = ["New to cybersecurity", "Some familiarity", "Working in the field"];
const VALID_TOPICS = ["Ransomware", "Data breaches", "Phishing", "Cloud security", "Vulnerabilities (CVEs)", "Identity / passwords", "Mobile threats", "AI threats"];
const MAX_TOPICS = VALID_TOPICS.length;
const MAX_DISPLAY_NAME_LENGTH = 80;

function assertOneOf(value: string, allowed: string[], field: string) {
  if (!allowed.includes(value)) {
    throw new Error(`Invalid value for ${field}`);
  }
}

function assertValidTopics(topics: string[]) {
  if (!Array.isArray(topics) || topics.length > MAX_TOPICS) {
    throw new Error("Invalid topics list");
  }
  for (const t of topics) {
    if (!VALID_TOPICS.includes(t)) {
      throw new Error(`Invalid topic: ${t}`);
    }
  }
}

export type Profile = {
  id: string;
  user_id: string;
  display_name: string | null;
  role: string | null;
  industry: string | null;
  experience_level: string | null;
  topics: string[];
  onboarding_complete: boolean;
  email_digest_enabled: boolean;
};

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!data) {
      // Auto-create a row if trigger somehow missed
      const { data: created, error: insErr } = await supabase
        .from("profiles")
        .insert({ user_id: userId })
        .select("*")
        .single();
      if (insErr) throw new Error(insErr.message);
      return created as unknown as Profile;
    }
    return data as unknown as Profile;
  });

export const updateMyProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: {
    display_name?: string;
    role?: string;
    industry?: string;
    experience_level?: string;
    topics?: string[];
    email_digest_enabled?: boolean;
  }) => data)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    if (data.display_name !== undefined) {
      if (typeof data.display_name !== "string" || data.display_name.length > MAX_DISPLAY_NAME_LENGTH) {
        throw new Error("Invalid display name");
      }
    }
    if (data.role !== undefined) assertOneOf(data.role, VALID_ROLES, "role");
    if (data.industry !== undefined) assertOneOf(data.industry, VALID_INDUSTRIES, "industry");
    if (data.experience_level !== undefined) assertOneOf(data.experience_level, VALID_LEVELS, "experience_level");
    if (data.topics !== undefined) assertValidTopics(data.topics);
    if (data.email_digest_enabled !== undefined && typeof data.email_digest_enabled !== "boolean") {
      throw new Error("Invalid email_digest_enabled");
    }

    // Build the update from an explicit allow-list. Never pass the raw input
    // to .update() — that would let a caller set columns this endpoint isn't
    // meant to touch (e.g. onboarding_complete, plan) by adding extra fields
    // to the request body (mass-assignment). Only the fields below are
    // user-settable through this function.
    const updates: Record<string, unknown> = {};
    if (data.display_name !== undefined) updates.display_name = data.display_name;
    if (data.role !== undefined) updates.role = data.role;
    if (data.industry !== undefined) updates.industry = data.industry;
    if (data.experience_level !== undefined) updates.experience_level = data.experience_level;
    if (data.topics !== undefined) updates.topics = data.topics;
    if (data.email_digest_enabled !== undefined) updates.email_digest_enabled = data.email_digest_enabled;

    if (Object.keys(updates).length === 0) {
      return { ok: true }; // nothing to update
    }

    const { error } = await supabase
      .from("profiles")
      .update(updates)
      .eq("user_id", userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const completeOnboarding = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: {
    role: string;
    industry: string;
    experience_level: string;
    topics: string[];
  }) => data)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    assertOneOf(data.role, VALID_ROLES, "role");
    assertOneOf(data.industry, VALID_INDUSTRIES, "industry");
    assertOneOf(data.experience_level, VALID_LEVELS, "experience_level");
    assertValidTopics(data.topics);

    const { error } = await supabase
      .from("profiles")
      .update({
        role: data.role,
        industry: data.industry,
        experience_level: data.experience_level,
        topics: data.topics,
        onboarding_complete: true,
      })
      .eq("user_id", userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
